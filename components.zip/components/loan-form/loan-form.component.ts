
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoanApplication } from 'src/app/models/loan-application.model';
import { LoanService } from 'src/app/services/loan.service';

@Component({
  selector: 'app-loan-form',
  templateUrl: './loan-form.component.html',
  styleUrls: ['./loan-form.component.css']
})
export class LoanFormComponent implements OnInit {

  loanForm : FormGroup;
  loansApp : LoanApplication;
  id : number;
  selectedFile: File | null = null;
  message: string | null = null;
  success=false;
  constructor(private loanService : LoanService, private formBuilder: FormBuilder, private router: Router, private activatedRoute : ActivatedRoute) { 
    this.loanForm = this.formBuilder.group({
      institution:formBuilder.control("",Validators.required),
      course:formBuilder.control("",Validators.required),
      tuitionFee:formBuilder.control(0,Validators.required),
      loanStatus :formBuilder.control(0),
      submissionDate:formBuilder.control(new Date().toISOString().split('T')[0]),
      address:formBuilder.control("",Validators.required),
      file:formBuilder.control(""),
      hasFeedback:formBuilder.control(0)
    })
  }

  public get institution():FormControl{
    return this.loanForm.get("institution") as FormControl;
  }

  public get course():FormControl{
    
    return this.loanForm.get("course") as FormControl;
  }

  public get tuitionFee():FormControl{
    return this.loanForm.get("tuitionFee") as FormControl;
  }

  public get address():FormControl{
    return this.loanForm.get("address") as FormControl;
  }

  public get file():FormControl{
    return this.loanForm.get("file") as FormControl;
  }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(i=>{
      this.id = i['id'];
    })
  }

  addLoan(){
   
       console.log(this.loanForm.value);
       console.log("osoos"+this.loanForm.value.tuitionFee);
    if(this.loanForm.valid){
      let  loanapplication :LoanApplication={
        user :{
          userId:parseInt(localStorage.getItem('userId'))
        },
        loan : {
          loanId:this.id
        },
        institution : this.loanForm.value.institution ,
        course : this.loanForm.value.course,
        tuitionFee : this.loanForm.value.tuitionFee,
        loanStatus :  this.loanForm.value.loanStatus,
        address : this.loanForm.value.address,
        submissionDate: this.loanForm.value.submissionDate,
      }
      //----------------
      return this.loanService.addLoanApplication(loanapplication).subscribe(data=>{
        this.upload(data.loanApplicationId);
        this.router.navigate(['/userLoanList']);
        this.success=true;
        console.log(this.loanForm.value);
      })
  }
}

onFileChange(event: any) {
  this.selectedFile = event.target.files[0];
}

upload(loanApplicationId : number) {
  console.log(this.selectedFile)
  if (this.selectedFile) {
    this.loanService.uploadImage(loanApplicationId,this.selectedFile).subscribe(
      response => {
        this.message = response;
        
      },
      error => {
        this.message = 'Error uploading file';
        console.log(error);
      }
    );
  } else {
    this.message = 'Please select a file first';
  }
}

public ok(){
  this.success=false;
}

openModal(){
  this.success=true;
  console.log("jdjjdj");
}

}



