
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-usernav',
  templateUrl: './usernav.component.html',
  styleUrls: ['./usernav.component.css']
})
export class UsernavComponent implements OnInit {

  username: string = ""; 
  val:string="";
  constructor(
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.getUsername(); 
  }

  getUsername(): void {
    const userId = parseInt(localStorage.getItem('userId')); 
    this.authService.getUserById(userId).subscribe(data => {
      this.username = data.username; 
    });
  }

  onClick(){
    if(this.val === "Add"){
      this.router.navigate(['/addUserFeedback']);
    }
    else if(this.val === "View"){
      this.router.navigate(['/viewUserFeedback']);
    }
  }

  logout(): void {
    this.authService.logout();
  }
}
