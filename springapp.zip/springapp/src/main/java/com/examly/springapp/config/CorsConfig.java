package com.examly.springapp.config;

import org.springframework.context.annotation.Bean;


public class CorsConfig {
   
}
