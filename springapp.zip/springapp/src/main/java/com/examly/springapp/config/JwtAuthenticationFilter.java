package com.examly.springapp.config;

import org.springframework.stereotype.Component;

@Component
public class JwtAuthenticationFilter {
    
}
