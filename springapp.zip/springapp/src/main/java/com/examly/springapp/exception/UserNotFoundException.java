package com.examly.springapp.exception;

public class UserNotFoundException extends RuntimeException{
    
}
